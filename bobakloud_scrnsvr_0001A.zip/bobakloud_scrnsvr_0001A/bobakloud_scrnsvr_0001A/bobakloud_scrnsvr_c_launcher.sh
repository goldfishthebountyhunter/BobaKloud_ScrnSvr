#!/bin/bash

#/--------------------------/
#/ goldfishthebountyhunter  /
#/                          /
#/  04/03/2025              /
#/                          /
#/  bobakloud_scrnsvr_0001A /
#/                          /
#/--------------------------/

# base64 -d program_base64.txt > decoded_program.c

# Checks if GCC is installed
if command -v gcc &>/dev/null; then
    echo "GCC is installed"
else
    echo "GCC is not installed, please install GCC"
    exit 1
fi

# Clean up old files
if [ -f /bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_program ]; then
    rm bobakloud_scrnsvr_program
fi

# List of source files Multiple
#src_files="path/to/dir1/file1.c path/to/dir2/file2.c path/to/dir3/file3.c"

# List Source Files
src_files="/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_unencrypted.c"

# Compile the C program
gcc -c /bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_program $src_files
if [ $? -eq 0 ]; then
    echo "Compilation successful!"
else
    echo "Compilation failed: initiating fallback.."
    exit 1
    # ./bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_encrypted_fallback.sh
    
fi

# Open Html & Run the banner program
open /bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_www.html && ./bobakloud_scrnsvr_program

# Other Sytnax Options

#$ google-chrome /bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_www.html
#$ firefox /bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_www.html
#$ microsoft-edge /bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_www.html
# Or
#$ open -a "Google Chrome" /bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_www.html
#$ open -a "Firefox" /bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_www.html