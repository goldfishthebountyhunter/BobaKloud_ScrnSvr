#!/bin/bash

#/--------------------------/
#/ goldfishthebountyhunter  /
#/                          /
#/  04/03/2025              /
#/                          /
#/  bobakloud_scrnsvr_0001A /
#/                          /
#/--------------------------/


# Srsly First Chmod
sudo chmod +x "/home/$(whoami)/desktop/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_c_builder.sh"
sudo chmod +x "/home/$(whoami)/desktop/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_c_launcher.sh"

# Also Run Service
./home/$(whoami)/desktop/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_more_dource/bobakloud_scrnsvr_somesrvice.sh