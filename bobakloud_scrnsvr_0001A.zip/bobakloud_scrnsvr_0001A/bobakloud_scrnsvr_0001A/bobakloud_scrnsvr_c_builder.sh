#!/bin/bash

#/--------------------------/
#/ goldfishthebountyhunter  /
#/                          /
#/  04/03/2025              /
#/                          /
#/  bobakloud_scrnsvr_0001A /
#/                          /
#/--------------------------/


# Srsly First Chmod
sudo chmod +x "/home/$(whoami)/desktop/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_c_builder.sh"
sudo chmod +x "/home/$(whoami)/desktop/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_c_launcher.sh"

# Also Run Service
./home/$(whoami)/desktop/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_more_dource/bobakloud_scrnsvr_somesrvice.sh



#    ___  ________  ___      ___ ________                      
#   |\  \|\   __  \|\  \    /  /|\   __  \                     
#   \ \  \ \  \|\  \ \  \  /  / | \  \|\  \                    
# __ \ \  \ \   __  \ \  \/  / / \ \   __  \                   
#|\  \\_\  \ \  \ \  \ \    / /   \ \  \ \  \                  
#\ \________\ \__\ \__\ \__/ /     \ \__\ \__\                 
# \|________|\|__|\|__|\|__|/       \|__|\|__|                                                                               
#                                                              
# _________  ___  ___  ___  ________   ________  ________      
#|\___   ___\\  \|\  \|\  \|\   ___  \|\   ____\|\   ____\     
#\|___ \  \_\ \  \\\  \ \  \ \  \\ \  \ \  \___|\ \  \___|_    
#     \ \  \ \ \   __  \ \  \ \  \\ \  \ \  \  __\ \_____  \   
#      \ \  \ \ \  \ \  \ \  \ \  \\ \  \ \  \|\  \|____|\  \  
#       \ \__\ \ \__\ \__\ \__\ \__\\ \__\ \_______\____\_\  \ 
#        \|__|  \|__|\|__|\|__|\|__| \|__|\|_______|\_________\
#                                                  \|_________|


# Java DL MIRRORS
# java[dum]com/en/download/manual.jsp # JRE8 Java 8
# oracle[dum]com/java/technologies/downloads/ JDK 24 

# Install Wildcard Java (unspecified Vers)
# $ sudo apt-get install default-jre  
# $ sudo apt-get install default-jdk

# Manual PAckage moving & Env setup
# $ sudo tar -xvf jdk-8u201-linux-i586.tar.gz
# $ sudo mkdir /usr/local/java
# $ sudo mv jdk-8u201-linux-i586.tar.gz /usr/local/java

# Install Java 
# $ sudo apt install default-jre

# Install Java 8
# $ sudo apt-get install oracle-java8-installer

# Install Java 10
# $ sudo apt-get install oracle-java10-installer
# $ sudo apt-get install oracle-java10-set-default

# Install Java 11
# $ sudo apt-get install oracle-java11-installer

# Install Java Developmental Kit 8
# $ sudo apt install openjdk-8-jdk
# $ sudo apt install openjdk-8-source #this is optional, the jdk source code
# $ export JAVA_HOME=/usr/lib/jvm/java-8-openjdk

# Install Java Developmental Kit 7
# $ tar -xvf ~/Downloads/jdk-7u3-linux-i586.tar.gz
# $ sudo mkdir -p /usr/lib/jvm/jdk1.7.0
# $ sudo mv jdk1.7.0_03/* /usr/lib/jvm/jdk1.7.0/
# $ sudo update-alternatives --install "/usr/bin/java" "java" "/usr/lib/jvm/jdk1.7.0/bin/java" 1
# $ sudo update-alternatives --install "/usr/bin/javac" "javac" "/usr/lib/jvm/jdk1.7.0/bin/javac" 1
# $ sudo update-alternatives --install "/usr/bin/javaws" "javaws" "/usr/lib/jvm/jdk1.7.0/bin/javaws" 1

##-----v---v------
# $ cat <<'EOF' >>/etc/profile
#JAVA_HOME=/usr/lib/jvm/jdk1.7.0
#PATH=$PATH:$HOME/bin:$JAVA_HOME/bin
#export JAVA_HOME
#export PATH
#EOF

# Test
# $ java -version
# $ java --version
# $ javac --version


# Java Compile Java Applet Html Thing
javac ./home/$(whoami)/Desktop/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_0001A/bobakloud_scrnsvr_dource/bobakloud_scrnsvr_more_dource/random_test_avenue/HelloWorld.java